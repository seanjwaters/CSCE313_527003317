Here comes the source code for MP1. The following files are included:

-- my_allocator.hpp/cpp : Header/Implementation files for the allocator.
    The implementation file contains placeholders for the implementations
    of the functions defined in the header. This code is operational
    as-is, but you need to replace the implementation with your code!

-- memtest.cpp : This file tests your allocator by calling the highly
   recursive function 'Ackerman', which in turn allocates and then
   frees memory many times over.  You will need to add the
   following to the main function in this file (at the marked locations):
   .. Processing of command-line arguments.

-- free_list.hpp/cpp: Heder/Implementation files for segment headers
    and free-lists. Currently the Add/Remove functions in class
    FreeList unceremoniously crash. You will need to add your
    implementation of these functions.
    
-- makefile : This file tells 'make' how to compile everything together.

